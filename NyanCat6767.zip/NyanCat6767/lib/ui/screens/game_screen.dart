import 'package:flutter/material.dart' hide Route;
import 'package:flame/game.dart' as flame_game;

class GameScreen extends StatelessWidget {
  const GameScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('NyanCat6767 Game')),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Използване на префикса за Route, за да няма конфликт с Material
            // flame_game.Route route = ...;
          },
          child: const Text('Старт на играта'),
        ),
      ),
    );
  }
}