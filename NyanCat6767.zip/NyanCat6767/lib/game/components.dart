import 'package:flame/components.dart';
import 'package:flame/game.dart';

class WorldDef {
  final String name;
  const WorldDef(this.name);
}

class GameWorldManager {
  WorldDef getSelectedWorld(World currentWorld) {
    // Коригирано кастване/присвояване на тип World към WorldDef
    return currentWorld as WorldDef;
  }
}